import { a as __toESM } from "../_runtime.mjs";
import { a as AnimatePresence, i as motion, n as useSpring, o as performance_default, r as useScroll, t as useInView } from "../_libs/framer-motion.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { C as FiX, S as FiUser, T as HiX, _ as FiMapPin, a as FiArrowDown, b as FiSend, c as FiBox, d as FiChevronLeft, f as FiChevronRight, g as FiMail, h as FiHeart, i as TbDrone, l as FiCamera, m as FiGift, n as FaInstagram, o as FiArrowUp, p as FiFilm, r as FaWhatsapp, s as FiAward, t as FaBehance, u as FiCheck, v as FiPhone, w as HiMenu, x as FiStar, y as FiPlus } from "../_libs/react-icons.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-75iVyJVu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links$1 = [
	{
		label: "Home",
		href: "#home"
	},
	{
		label: "About",
		href: "#about"
	},
	{
		label: "Portfolio",
		href: "#portfolio"
	},
	{
		label: "Services",
		href: "#services"
	},
	{
		label: "Packages",
		href: "#packages"
	},
	{
		label: "Testimonials",
		href: "#testimonials"
	},
	{
		label: "Contact",
		href: "#contact"
	}
];
function Navbar() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 20);
		onScroll();
		window.addEventListener("scroll", onScroll);
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.header, {
		initial: {
			y: -40,
			opacity: 0
		},
		animate: {
			y: 0,
			opacity: 1
		},
		transition: {
			duration: .6,
			ease: [
				.22,
				1,
				.36,
				1
			]
		},
		className: `fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? "glass py-3" : "py-5 bg-transparent"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl items-center justify-between px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#home",
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-2xl tracking-wide text-foreground",
						children: ["KING", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gold-gradient",
							children: "⟶"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-8 lg:flex",
					children: links$1.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: l.href,
						className: "group relative text-sm uppercase tracking-[0.15em] text-muted-foreground transition hover:text-foreground",
						children: [l.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -bottom-1 left-0 h-px w-0 gold-gradient transition-all duration-300 group-hover:w-full" })]
					}, l.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#contact",
					className: "hidden rounded-full border border-gold/40 px-5 py-2 text-xs uppercase tracking-[0.2em] text-gold transition hover:bg-gold hover:text-background lg:inline-flex",
					children: "Book a Session"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setOpen((v) => !v),
					className: "text-foreground lg:hidden",
					"aria-label": "Menu",
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HiX, { size: 26 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HiMenu, { size: 26 })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.nav, {
			initial: {
				height: 0,
				opacity: 0
			},
			animate: {
				height: "auto",
				opacity: 1
			},
			exit: {
				height: 0,
				opacity: 0
			},
			className: "overflow-hidden lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-6 mt-4 flex flex-col gap-4 rounded-2xl glass p-6",
				children: [links$1.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: l.href,
					onClick: () => setOpen(false),
					className: "text-sm uppercase tracking-[0.15em] text-muted-foreground hover:text-gold",
					children: l.label
				}, l.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#contact",
					onClick: () => setOpen(false),
					className: "mt-2 rounded-full gold-gradient px-5 py-2 text-center text-xs uppercase tracking-[0.2em] text-background",
					children: "Book a Session"
				})]
			})
		}) })]
	});
}
var hero_default = "/assets/hero-CZszX-Au.jpg";
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "home",
		className: "relative flex min-h-screen items-center justify-center overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.img, {
				src: hero_default,
				alt: "Cinematic photography hero",
				width: 1920,
				height: 1280,
				initial: { scale: 1.15 },
				animate: { scale: 1 },
				transition: {
					duration: 2.4,
					ease: [
						.22,
						1,
						.36,
						1
					]
				},
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-background/70 via-background/40 to-background" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-background/40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto max-w-5xl px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							delay: .4,
							duration: .8
						},
						className: "mb-6 text-xs uppercase tracking-[0.4em] text-gold",
						children: "— Luxury Photography Studio —"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.h1, {
						initial: {
							opacity: 0,
							y: 30
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							delay: .6,
							duration: 1
						},
						className: "font-display text-5xl leading-[1.05] text-foreground sm:text-7xl md:text-8xl",
						children: [
							"Capturing Moments ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"That Last ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "text-gold-gradient not-italic",
								children: "Forever"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							delay: .9,
							duration: .8
						},
						className: "mx-auto mt-8 max-w-2xl text-base text-muted-foreground sm:text-lg",
						children: "Professional wedding, portrait, event and lifestyle photography — crafted with a cinematic eye and an obsession for timeless detail."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							delay: 1.1,
							duration: .8
						},
						className: "mt-10 flex flex-wrap items-center justify-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contact",
							className: "group relative overflow-hidden rounded-full gold-gradient px-8 py-3 text-sm font-medium uppercase tracking-[0.2em] text-background transition hover:shadow-[0_0_40px_rgba(212,175,55,0.4)]",
							children: "Book Now"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#portfolio",
							className: "rounded-full border border-foreground/30 px-8 py-3 text-sm uppercase tracking-[0.2em] text-foreground transition hover:border-gold hover:text-gold",
							children: "View Portfolio"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.a, {
				href: "#about",
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				transition: {
					delay: 1.6,
					duration: 1
				},
				className: "absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-muted-foreground",
				"aria-label": "Scroll down",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] uppercase tracking-[0.4em]",
						children: "Scroll"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiArrowDown, {
						className: "animate-scroll-hint",
						size: 18
					})]
				})
			})
		]
	});
}
var variants = {
	hidden: {
		opacity: 0,
		y: 40
	},
	visible: {
		opacity: 1,
		y: 0,
		transition: {
			duration: .9,
			ease: [
				.22,
				1,
				.36,
				1
			]
		}
	}
};
function Reveal({ children, className, delay = 0 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		initial: "hidden",
		whileInView: "visible",
		viewport: {
			once: true,
			margin: "-80px"
		},
		variants,
		transition: { delay },
		className,
		children
	});
}
function SectionHeader({ eyebrow, title, subtitle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
		className: "mx-auto mb-16 max-w-2xl text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-4 text-xs uppercase tracking-[0.4em] text-gold",
				children: [
					"— ",
					eyebrow,
					" —"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl leading-tight text-foreground sm:text-5xl md:text-6xl",
				children: title
			}),
			subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-muted-foreground",
				children: subtitle
			})
		]
	});
}
var hero1_default = "/assets/hero1-BW0a__4b.png";
var cards = [
	{
		icon: FiCamera,
		title: "Cinematic Eye",
		desc: "Every frame composed like a still from film."
	},
	{
		icon: FiHeart,
		title: "Real Emotion",
		desc: "We photograph feelings, not just faces."
	},
	{
		icon: FiAward,
		title: "Award Winning",
		desc: "Recognized by international photography guilds."
	},
	{
		icon: FiStar,
		title: "5-Star Service",
		desc: "White-glove experience from first call to final gallery."
	}
];
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "about",
		className: "relative py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-16 px-6 lg:grid-cols-2 lg:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -left-4 -top-4 h-full w-full rounded-2xl border border-gold/30" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: hero1_default,
						alt: "Photographer portrait",
						width: 900,
						height: 1100,
						loading: "lazy",
						className: "relative aspect-[4/5] w-full rounded-2xl object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute -bottom-6 -right-6 rounded-2xl glass px-6 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-3xl text-gold-gradient font-display",
							children: "10+"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: "Years of craft"
						})]
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-xs uppercase tracking-[0.4em] text-gold",
					children: "— About the Studio —"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-4xl leading-tight text-foreground sm:text-5xl",
					children: [
						"A quiet obsession with ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "text-gold-gradient not-italic",
							children: "light, story"
						}),
						" and the moments in between."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-muted-foreground",
					children: "I'm  Poovarasan, a photographer with 10 years of experience capturing stories through my lens. From events to creative projects, I approach every shoot with passion, precision, and a drive to exceed expectations. I thrive under pressure, value client satisfaction, and constantly push my creativity to deliver impactful visual results."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid grid-cols-2 gap-4",
				children: cards.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .08,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "group h-full rounded-2xl border border-border bg-surface/50 p-5 transition hover:border-gold/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, {
								className: "text-gold",
								size: 22
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-display text-xl text-foreground",
								children: c.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: c.desc
							})
						]
					})
				}, c.title))
			})] })]
		})
	});
}
var items$1 = [
	{
		src: "/assets/p1-DrLMYt12.jpg",
		cat: "Wedding",
		title: "The Vow"
	},
	{
		src: "/assets/p15-DgBoE-Ze.JPG",
		cat: "Wedding",
		title: "The Vow"
	},
	{
		src: "/assets/p11-D8DpArk9.JPG",
		cat: "Portrait",
		title: ""
	},
	{
		src: "/assets/p12-CzdligUf.JPG",
		cat: "Portrait",
		title: ""
	},
	{
		src: "/assets/p2-BIhfbOpg.jpg",
		cat: "Pre Wedding",
		title: "Misty Fields"
	},
	{
		src: "/assets/p5-BlaYXKKm.jpg",
		cat: "Fashion",
		title: "Noir Editorial"
	},
	{
		src: "/assets/p9-rlJ2tQ90.JPG",
		cat: "Fashion",
		title: "Movie Shoot"
	},
	{
		src: "/assets/p10-BmFwiVez.PNG",
		cat: "Fashion",
		title: "Movie Shoot"
	},
	{
		src: "/assets/p4-COfLXhtX.jpg",
		cat: "Nature",
		title: "Alpine Light"
	},
	{
		src: "/assets/p6-D8wy_aOi.jpg",
		cat: "Events",
		title: "Nights"
	},
	{
		src: "/assets/p13-CnSlDtBG.JPG",
		cat: "Events",
		title: "Shoot"
	},
	{
		src: "/assets/p14-DZzK-TgJ.JPG",
		cat: "Events",
		title: "Shoot"
	},
	{
		src: "/assets/p7-BkCJSc-K.jpeg",
		cat: "Portrait",
		title: "Quiet Study"
	},
	{
		src: "/assets/p16-Cd5upZtS.JPG",
		cat: "Portrait",
		title: "Actor SK"
	},
	{
		src: "/assets/p17-BiD1H1oY.JPG",
		cat: "Portrait",
		title: "Actor SK"
	}
];
var cats = [
	"All",
	"Wedding",
	"Pre Wedding",
	"Portrait",
	"Nature",
	"Fashion",
	"Events"
];
function Portfolio() {
	const [active, setActive] = (0, import_react.useState)("All");
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const filtered = (0, import_react.useMemo)(() => active === "All" ? items$1 : items$1.filter((i) => i.cat === active), [active]);
	const close = (0, import_react.useCallback)(() => setLightbox(null), []);
	const next = (0, import_react.useCallback)(() => setLightbox((v) => v === null ? null : (v + 1) % filtered.length), [filtered.length]);
	const prev = (0, import_react.useCallback)(() => setLightbox((v) => v === null ? null : (v - 1 + filtered.length) % filtered.length), [filtered.length]);
	(0, import_react.useEffect)(() => {
		if (lightbox === null) return;
		const onKey = (e) => {
			if (e.key === "Escape") close();
			if (e.key === "ArrowRight") next();
			if (e.key === "ArrowLeft") prev();
		};
		window.addEventListener("keydown", onKey);
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = "";
		};
	}, [
		lightbox,
		close,
		next,
		prev
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "portfolio",
		className: "relative bg-surface/40 py-32",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					eyebrow: "Selected Work",
					title: "A gallery of stories",
					subtitle: "A curated selection from recent weddings, editorials and journeys."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "mb-12 flex flex-wrap justify-center gap-2",
					children: cats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setActive(c),
						className: `rounded-full border px-5 py-2 text-xs uppercase tracking-[0.2em] transition ${active === c ? "border-gold bg-gold text-background" : "border-border text-muted-foreground hover:border-gold/50 hover:text-foreground"}`,
						children: c
					}, c))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					layout: true,
					className: "columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: filtered.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
						layout: true,
						initial: {
							opacity: 0,
							y: 30
						},
						animate: {
							opacity: 1,
							y: 0
						},
						exit: { opacity: 0 },
						transition: {
							duration: .5,
							delay: idx * .04
						},
						onClick: () => setLightbox(idx),
						className: "group relative block w-full overflow-hidden rounded-xl break-inside-avoid",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: item.src,
							alt: item.title,
							loading: "lazy",
							className: "w-full transition-transform duration-[1200ms] ease-out group-hover:scale-110"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-none absolute inset-0 flex items-end bg-gradient-to-t from-background/90 via-background/20 to-transparent p-5 opacity-0 transition-opacity duration-500 group-hover:opacity-100",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.3em] text-gold",
								children: item.cat
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 font-display text-2xl text-foreground",
								children: item.title
							})] })
						})]
					}, item.src + idx + active)) })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: lightbox !== null && filtered[lightbox] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: { opacity: 0 },
			animate: { opacity: 1 },
			exit: { opacity: 0 },
			className: "fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-xl p-4",
			onClick: close,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: close,
					className: "absolute right-6 top-6 rounded-full border border-border p-2 text-foreground hover:border-gold hover:text-gold",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiX, { size: 24 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: (e) => {
						e.stopPropagation();
						prev();
					},
					className: "absolute left-4 rounded-full border border-border p-3 text-foreground hover:border-gold hover:text-gold sm:left-8",
					"aria-label": "Previous",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiChevronLeft, { size: 24 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.img, {
					initial: {
						opacity: 0,
						scale: .96
					},
					animate: {
						opacity: 1,
						scale: 1
					},
					exit: { opacity: 0 },
					src: filtered[lightbox].src,
					alt: filtered[lightbox].title,
					className: "max-h-[85vh] max-w-[90vw] rounded-lg object-contain",
					onClick: (e) => e.stopPropagation()
				}, lightbox),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: (e) => {
						e.stopPropagation();
						next();
					},
					className: "absolute right-4 rounded-full border border-border p-3 text-foreground hover:border-gold hover:text-gold sm:right-8",
					"aria-label": "Next",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiChevronRight, { size: 24 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute bottom-6 left-1/2 -translate-x-1/2 text-xs uppercase tracking-[0.3em] text-muted-foreground",
					children: [
						lightbox + 1,
						" / ",
						filtered.length,
						" — ",
						filtered[lightbox].title
					]
				})
			]
		}) })]
	});
}
var services = [
	{
		icon: FiHeart,
		title: "Wedding Photography",
		desc: "Full-day storytelling from getting ready to last dance."
	},
	{
		icon: FiCamera,
		title: "Pre Wedding",
		desc: "Cinematic engagement sessions in bespoke locations."
	},
	{
		icon: FiGift,
		title: "Birthday Shoot",
		desc: "Editorial-style celebrations for milestone moments."
	},
	{
		icon: FiUser,
		title: "Portrait Shoot",
		desc: "Personal, brand and family portraits with soul."
	},
	{
		icon: FiBox,
		title: "Product Photography",
		desc: "Luxury still life for premium brands and e-commerce."
	},
	{
		icon: TbDrone,
		title: "Drone Photography",
		desc: "Sweeping aerial cinematography for grand venues."
	},
	{
		icon: FiFilm,
		title: "Cinematic Video",
		desc: "Short films that play like a director's cut."
	}
];
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "services",
		className: "relative py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				eyebrow: "What We Offer",
				title: "Services crafted with intention",
				subtitle: "Every project begins with a conversation and ends with a heirloom."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: services.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .05,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "group relative h-full overflow-hidden rounded-2xl border border-border bg-surface/60 p-8 transition duration-500 hover:-translate-y-2 hover:border-gold/50 hover:shadow-[0_20px_60px_-20px_rgba(212,175,55,0.3)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent opacity-0 transition group-hover:opacity-100" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-6 inline-flex h-14 w-14 items-center justify-center rounded-full border border-gold/30 text-gold transition group-hover:gold-gradient group-hover:text-background",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { size: 24 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl text-foreground",
								children: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted-foreground",
								children: s.desc
							})
						]
					})
				}, s.title))
			})]
		})
	});
}
var tiers = [
	{
		name: "Essence",
		price: "5,000",
		tag: "Basic",
		features: [
			"4 hours coverage",
			"1 photographer",
			"80+ edited photos",
			"Online gallery",
			"Personal use license"
		],
		highlight: false
	},
	{
		name: "Signature",
		price: "10,000",
		tag: "Premium",
		features: [
			"8 hours coverage",
			"2 photographers",
			"300+ edited photos",
			"Cinematic highlight film",
			"Fine-art proof box",
			"Print release included"
		],
		highlight: true
	},
	{
		name: "Heritage",
		price: "20,000",
		tag: "Luxury",
		features: [
			"Full-day coverage",
			"Lead + 2 photographers",
			"600+ edited photos",
			"Feature film + teaser",
			"Handcrafted heirloom album",
			"Drone & second location",
			"Priority scheduling"
		],
		highlight: false
	}
];
function Packages() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "packages",
		className: "relative bg-surface/40 py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				eyebrow: "Investment",
				title: "Curated packages",
				subtitle: "Transparent pricing. Every collection is fully customizable to your day."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 lg:grid-cols-3",
				children: tiers.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .1,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `relative flex h-full flex-col rounded-3xl border p-8 transition duration-500 hover:-translate-y-2 ${t.highlight ? "border-gold/60 bg-gradient-to-b from-gold/10 to-transparent shadow-[0_30px_80px_-30px_rgba(212,175,55,0.5)]" : "border-border bg-surface/60 hover:border-gold/40"}`,
						children: [
							t.highlight && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute -top-3 left-1/2 -translate-x-1/2 rounded-full gold-gradient px-4 py-1 text-[10px] uppercase tracking-[0.3em] text-background",
								children: "Most Loved"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.3em] text-gold",
								children: t.tag
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-display text-4xl text-foreground",
								children: t.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 font-display text-5xl text-gold-gradient",
								children: t.price
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "starting investment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-8 flex-1 space-y-3",
								children: t.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-3 text-sm text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiCheck, { className: "mt-1 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: f })]
								}, f))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#contact",
								className: `mt-8 block rounded-full py-3 text-center text-xs uppercase tracking-[0.25em] transition ${t.highlight ? "gold-gradient text-background hover:shadow-[0_0_40px_rgba(212,175,55,0.5)]" : "border border-foreground/30 text-foreground hover:border-gold hover:text-gold"}`,
								children: "Book Now"
							})
						]
					})
				}, t.name))
			})]
		})
	});
}
var stats = [
	{
		value: 500,
		suffix: "+",
		label: "Happy Clients"
	},
	{
		value: 1e3,
		suffix: "+",
		label: "Projects Completed"
	},
	{
		value: 10,
		suffix: "+",
		label: "Years Experience"
	},
	{
		value: 98,
		suffix: "%",
		label: "Client Satisfaction"
	}
];
function Counter({ end, suffix }) {
	const ref = (0, import_react.useRef)(null);
	const inView = useInView(ref, {
		once: true,
		margin: "-40px"
	});
	const [n, setN] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!inView) return;
		const dur = 2e3;
		const start = performance_default.now();
		let raf = 0;
		const tick = (t) => {
			const p = Math.min((t - start) / dur, 1);
			const eased = 1 - Math.pow(1 - p, 3);
			setN(Math.floor(eased * end));
			if (p < 1) raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [inView, end]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		ref,
		className: "font-display text-5xl text-gold-gradient sm:text-6xl",
		children: [n, suffix]
	});
}
function Stats() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative border-y border-border py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-6 sm:grid-cols-2 lg:grid-cols-4",
			children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, {
					end: s.value,
					suffix: s.suffix
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs uppercase tracking-[0.3em] text-muted-foreground",
					children: s.label
				})]
			}, s.label))
		})
	});
}
var items = [
	{
		name: "Arshath & Shafi",
		role: "Wedding ",
		quote: "Poovarasan didn't just photograph our wedding — he preserved the way it felt. Every image is a heirloom. We'll cherish them for generations.",
		rating: 5
	},
	{
		name: "Ayesha",
		role: "BirthDay ",
		quote: "The most intuitive photographer I've worked with. Cinematic, calm, and endlessly creative. The gallery arrived and I cried.",
		rating: 5
	},
	{
		name: "Yuvaraj",
		role: "Ear Piercing",
		quote: "Warm, patient and quietly brilliant. The photos feel like a scene from a film we didn't know we were living.",
		rating: 5
	}
];
function Testimonials() {
	const [i, setI] = (0, import_react.useState)(0);
	const item = items[i];
	const next = () => setI((v) => (v + 1) % items.length);
	const prev = () => setI((v) => (v - 1 + items.length) % items.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "testimonials",
		className: "relative py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				eyebrow: "Kind Words",
				title: "What clients say"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-3xl glass p-10 sm:p-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
					mode: "wait",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						exit: {
							opacity: 0,
							y: -20
						},
						transition: { duration: .5 },
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-6 flex justify-center gap-1",
								children: Array.from({ length: item.rating }).map((_, k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiStar, { className: "fill-current text-gold" }, k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-2xl leading-relaxed text-foreground sm:text-3xl",
								children: [
									"\"",
									item.quote,
									"\""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg text-gold-gradient",
									children: item.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs uppercase tracking-[0.3em] text-muted-foreground",
									children: item.role
								})]
							})
						]
					}, i)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex items-center justify-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: prev,
							className: "rounded-full border border-border p-3 text-foreground transition hover:border-gold hover:text-gold",
							"aria-label": "Previous",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiChevronLeft, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: items.map((_, k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setI(k),
								className: `h-1.5 rounded-full transition-all ${k === i ? "w-8 bg-gold" : "w-1.5 bg-border"}`,
								"aria-label": `Slide ${k + 1}`
							}, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: next,
							className: "rounded-full border border-border p-3 text-foreground transition hover:border-gold hover:text-gold",
							"aria-label": "Next",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiChevronRight, {})
						})
					]
				})]
			})]
		})
	});
}
var faqs = [
	{
		q: "How far in advance should I book?",
		a: "Weddings are typically booked 6–14 months in advance. Portrait and editorial sessions usually 4–6 weeks out."
	},
	{
		q: "Do you travel internationally?",
		a: "Absolutely. We've shot in over 20 countries. Travel is quoted transparently as a flat add-on."
	},
	{
		q: "When will I receive my photos?",
		a: "A curated preview arrives within 72 hours. Full galleries deliver in 4–6 weeks, films in 8–10 weeks."
	},
	{
		q: "Can we customize a package?",
		a: "Yes — every collection can be tailored. Reach out and we'll design one around your day."
	},
	{
		q: "Do you offer albums and prints?",
		a: "We offer handcrafted fine-art albums, framed prints and archival boxes through partner ateliers."
	}
];
function FAQ() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "faq",
		className: "relative bg-surface/40 py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				eyebrow: "Answers",
				title: "Frequently asked"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: faqs.map((f, i) => {
					const isOpen = open === i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-2xl border border-border bg-surface/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setOpen(isOpen ? null : i),
							className: "flex w-full items-center justify-between gap-4 p-6 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-lg text-foreground sm:text-xl",
								children: f.q
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiPlus, {
								className: `shrink-0 text-gold transition-transform duration-500 ${isOpen ? "rotate-45" : ""}`,
								size: 22
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
							initial: false,
							children: isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								initial: {
									height: 0,
									opacity: 0
								},
								animate: {
									height: "auto",
									opacity: 1
								},
								exit: {
									height: 0,
									opacity: 0
								},
								transition: {
									duration: .4,
									ease: [
										.22,
										1,
										.36,
										1
									]
								},
								className: "overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-6 pb-6 text-muted-foreground",
									children: f.a
								})
							})
						})]
					}, f.q);
				})
			})]
		})
	});
}
function Contact() {
	const [sent, setSent] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contact",
		className: "relative py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				eyebrow: "Get in Touch",
				title: "Let's create something timeless",
				subtitle: "Tell us about your day. We reply to every inquiry within 24 hours."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "lg:col-span-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: (e) => {
							e.preventDefault();
							setSent(true);
						},
						className: "grid gap-4 rounded-3xl border border-border bg-surface/60 p-8 sm:p-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									label: "Name",
									name: "name",
									placeholder: "Your full name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									label: "Email",
									name: "email",
									type: "email",
									placeholder: "you@studio.com"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								label: "Phone",
								name: "phone",
								placeholder: "+(91) 12345-67890"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-2 block text-xs uppercase tracking-[0.3em] text-muted-foreground",
								children: "Message"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 5,
								required: true,
								placeholder: "Tell us about your project...",
								className: "w-full rounded-xl border border-border bg-background/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:border-gold focus:outline-none"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "submit",
								className: "group inline-flex items-center justify-center gap-2 rounded-full gold-gradient px-8 py-3 text-xs uppercase tracking-[0.25em] text-background transition hover:shadow-[0_0_40px_rgba(212,175,55,0.4)]",
								children: [
									sent ? "Message sent" : "Send message",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiSend, { className: "transition group-hover:translate-x-1" })
								]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "lg:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-full flex-col gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
								icon: FiPhone,
								label: "Call",
								value: "+91 7358698040",
								href: "tel:+91 7358698040"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
								icon: FaWhatsapp,
								label: "WhatsApp",
								value: "Chat with us",
								href: "https://wa.me/917358698040"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
								icon: FiMail,
								label: "Email",
								value: "poovarsanphotography24@gmail.com",
								href: "mailto:poovarsanphotography24@gmail.com"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
								icon: FiMapPin,
								label: "Studio",
								value: "No:13/4,Srinivasa Nagar ,Koyambedu,Chennai",
								href: "#map"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 overflow-hidden rounded-2xl border border-border",
								id: "map",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
									title: "Studio location",
									src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1943.9935203210084!2d80.21214911256214!3d12.972680561070437!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525d939fd5fea9%3A0x82481cd7c51598a6!2sSrinivasa%20Nagar%202nd%20St%2C%20Srinivasa%20Nagar%2C%20Velachery%2C%20Greater%20Chennai%2C%20Chennai%2C%20Tamil%20Nadu%20600042!5e0!3m2!1sen!2sin!4v1784279564464!5m2!1sen!2sin",
									className: "h-56 w-full grayscale contrast-125",
									loading: "lazy"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-3",
								children: [{
									Icon: FaInstagram,
									href: "https://www.instagram.com/poovarasanphotography?igsh=MTVvdzBuejhkamx0dA%3D%3D&utm_source=qr"
								}, {
									Icon: FaBehance,
									href: "https://www.behance.net/poovaraphotogr"
								}].map(({ Icon, href }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href,
									className: "flex h-11 w-11 items-center justify-center rounded-full border border-border text-foreground transition hover:border-gold hover:text-gold",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
								}, i))
							})
						]
					})
				})]
			})]
		})
	});
}
function Input({ label, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: "mb-2 block text-xs uppercase tracking-[0.3em] text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...rest,
		required: true,
		className: "w-full rounded-xl border border-border bg-background/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:border-gold focus:outline-none"
	})] });
}
function ContactRow({ icon: Icon, label, value, href }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href,
		className: "group flex items-center gap-4 rounded-2xl border border-border bg-surface/60 p-5 transition hover:border-gold/50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/30 text-gold transition group-hover:gold-gradient group-hover:text-background",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 18 })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-[10px] uppercase tracking-[0.3em] text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate font-display text-lg text-foreground",
				children: value
			})]
		})]
	});
}
var links = [
	"Home",
	"About",
	"Portfolio",
	"Services",
	"Packages",
	"Contact"
];
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border bg-surface/40 pt-16 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-6 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-display text-3xl text-foreground",
					children: ["KING", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold-gradient",
						children: "MEDIA"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-sm text-sm text-muted-foreground",
					children: "A luxury photography studio crafting cinematic stories for people who value the extraordinary."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-xs uppercase tracking-[0.3em] text-gold",
					children: "Quick Links"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-2 gap-2 text-sm",
					children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `#${l.toLowerCase()}`,
						className: "text-muted-foreground transition hover:text-gold",
						children: l
					}) }, l))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-xs uppercase tracking-[0.3em] text-gold",
					children: "Follow"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-3",
					children: [FaInstagram, FaBehance].map((Icon, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#",
						className: "flex h-10 w-10 items-center justify-center rounded-full border border-border text-foreground transition hover:border-gold hover:text-gold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
					}, i))
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-12 flex max-w-7xl flex-col items-center justify-between gap-3 border-t border-border px-6 pt-6 text-xs text-muted-foreground sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" KINGMEDIA Studio. All rights reserved."
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Crafted with obsession in Chennai." })]
		})]
	});
}
function ScrollProgress() {
	const { scrollYProgress } = useScroll();
	const scaleX = useSpring(scrollYProgress, {
		stiffness: 120,
		damping: 30,
		restDelta: .001
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		style: { scaleX },
		className: "fixed inset-x-0 top-0 z-[60] h-[2px] origin-left gold-gradient"
	});
}
function BackToTop() {
	const [show, setShow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const on = () => setShow(window.scrollY > 600);
		window.addEventListener("scroll", on);
		return () => window.removeEventListener("scroll", on);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: show && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.button, {
		initial: {
			opacity: 0,
			scale: .8
		},
		animate: {
			opacity: 1,
			scale: 1
		},
		exit: {
			opacity: 0,
			scale: .8
		},
		onClick: () => window.scrollTo({
			top: 0,
			behavior: "smooth"
		}),
		className: "fixed bottom-6 right-6 z-50 flex h-12 w-12 items-center justify-center rounded-full gold-gradient text-background shadow-lg transition hover:shadow-[0_0_30px_rgba(212,175,55,0.5)]",
		"aria-label": "Back to top",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FiArrowUp, { size: 20 })
	}) });
}
function Loader() {
	const [gone, setGone] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setGone(true), 1400);
		return () => clearTimeout(t);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: !gone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		initial: { opacity: 1 },
		exit: {
			opacity: 0,
			transition: { duration: .6 }
		},
		className: "fixed inset-0 z-[200] flex items-center justify-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			initial: {
				opacity: 0,
				letterSpacing: "0.05em"
			},
			animate: {
				opacity: 1,
				letterSpacing: "0.4em"
			},
			transition: {
				duration: 1.1,
				ease: [
					.22,
					1,
					.36,
					1
				]
			},
			className: "font-display text-3xl uppercase text-gold-gradient",
			children: "King Media⟶"
		})
	}) });
}
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollProgress, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portfolio, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Packages, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQ, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackToTop, {})
		]
	});
}
//#endregion
export { Index as component };
