//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Xp0rdIHj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Kaja/OneDrive/Desktop/project/pixel-enchant-web/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BrfVLYNz.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BrfVLYNz.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Kaja/OneDrive/Desktop/project/pixel-enchant-web/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CmdjCOlv.js"]
	}
} });
//#endregion
export { tsrStartManifest };
