globalThis.__nitro_main__ = import.meta.url;
import { a as FastResponse, n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"3aee-niJFeANBCT/zsV1GuOwFg/lMRDo\"",
		"mtime": "2026-07-17T05:35:10.000Z",
		"size": 15086,
		"path": "../public/favicon.ico"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"17-ZZkCVrbr4BSdjt/K43J0tq8+Qq4\"",
		"mtime": "2026-07-16T16:01:57.978Z",
		"size": 23,
		"path": "../public/robots.txt"
	},
	"/assets/hero-CZszX-Au.jpg": {
		"type": "image/jpeg",
		"etag": "\"154e8-5/spoZia5QyvMN3qUDtUlMnFoH4\"",
		"mtime": "2026-07-17T11:48:08.801Z",
		"size": 87272,
		"path": "../public/assets/hero-CZszX-Au.jpg"
	},
	"/assets/p1-DrLMYt12.jpg": {
		"type": "image/jpeg",
		"etag": "\"138fe-u7LVbSGFeg8aw9e/TrCw4WIyGe4\"",
		"mtime": "2026-07-17T11:48:08.807Z",
		"size": 80126,
		"path": "../public/assets/p1-DrLMYt12.jpg"
	},
	"/assets/index-BrfVLYNz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5444d-UljyUdvF6yNNNw5Bg9omSfB3IpY\"",
		"mtime": "2026-07-17T11:48:08.462Z",
		"size": 345165,
		"path": "../public/assets/index-BrfVLYNz.js"
	},
	"/assets/p14-DZzK-TgJ.JPG": {
		"type": "image/jpeg",
		"etag": "\"1dd6a-neEa6lE4eKdclhlPR3CXKPaVoSU\"",
		"mtime": "2026-07-17T11:48:08.818Z",
		"size": 122218,
		"path": "../public/assets/p14-DZzK-TgJ.JPG"
	},
	"/assets/p2-BIhfbOpg.jpg": {
		"type": "image/jpeg",
		"etag": "\"f8c2-Eg/Wnl0f6foZH+tmXg2fHR4QFUw\"",
		"mtime": "2026-07-17T11:48:08.827Z",
		"size": 63682,
		"path": "../public/assets/p2-BIhfbOpg.jpg"
	},
	"/assets/p4-COfLXhtX.jpg": {
		"type": "image/jpeg",
		"etag": "\"a76c-FnOb2noEk47tQG4YeZizt5SBpsc\"",
		"mtime": "2026-07-17T11:48:08.828Z",
		"size": 42860,
		"path": "../public/assets/p4-COfLXhtX.jpg"
	},
	"/assets/p5-BlaYXKKm.jpg": {
		"type": "image/jpeg",
		"etag": "\"f7e0-fwEu2py0q9YfpkiL3Qie0/dwqqM\"",
		"mtime": "2026-07-17T11:48:08.829Z",
		"size": 63456,
		"path": "../public/assets/p5-BlaYXKKm.jpg"
	},
	"/assets/p6-D8wy_aOi.jpg": {
		"type": "image/jpeg",
		"etag": "\"1c33e-vwY3ti81eB/o8dVJPoonqX1eFv0\"",
		"mtime": "2026-07-17T11:48:08.831Z",
		"size": 115518,
		"path": "../public/assets/p6-D8wy_aOi.jpg"
	},
	"/assets/styles-C8V4wmn1.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14142-HVpw+iuZrQmBX7H9rN/3qr3BSqo\"",
		"mtime": "2026-07-17T11:48:08.836Z",
		"size": 82242,
		"path": "../public/assets/styles-C8V4wmn1.css"
	},
	"/assets/routes-CmdjCOlv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b9db-DCJsQ6bgPrXz5rEd13CQaX2lhWk\"",
		"mtime": "2026-07-17T11:48:08.676Z",
		"size": 178651,
		"path": "../public/assets/routes-CmdjCOlv.js"
	},
	"/assets/p11-D8DpArk9.JPG": {
		"type": "image/jpeg",
		"etag": "\"bc415-GEpxoVpn51NEC2tf+Yd4sjU2dUM\"",
		"mtime": "2026-07-17T11:48:08.809Z",
		"size": 771093,
		"path": "../public/assets/p11-D8DpArk9.JPG"
	},
	"/assets/p12-CzdligUf.JPG": {
		"type": "image/jpeg",
		"etag": "\"cd11e-FuwkwbQ2F2Q3Pn++SZBX95ogS2I\"",
		"mtime": "2026-07-17T11:48:08.810Z",
		"size": 839966,
		"path": "../public/assets/p12-CzdligUf.JPG"
	},
	"/assets/p17-BiD1H1oY.JPG": {
		"type": "image/jpeg",
		"etag": "\"85cdd-uWN3/oT129C52Sj5iVh4FxZaPbQ\"",
		"mtime": "2026-07-17T11:48:08.826Z",
		"size": 548061,
		"path": "../public/assets/p17-BiD1H1oY.JPG"
	},
	"/assets/p9-rlJ2tQ90.JPG": {
		"type": "image/jpeg",
		"etag": "\"e5456-+cjj7C8VfiBDaiz699R3XEc9/EE\"",
		"mtime": "2026-07-17T11:48:08.835Z",
		"size": 939094,
		"path": "../public/assets/p9-rlJ2tQ90.JPG"
	},
	"/assets/p10-BmFwiVez.PNG": {
		"type": "image/png",
		"etag": "\"10adbe-+5mdw3rMKPalTseiOF2/3NWYdU0\"",
		"mtime": "2026-07-17T11:48:08.807Z",
		"size": 1093054,
		"path": "../public/assets/p10-BmFwiVez.PNG"
	},
	"/assets/p7-BkCJSc-K.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1cfb3e-IIjT3qfUJ/0TDG9Zagaw/bOCtiM\"",
		"mtime": "2026-07-17T11:48:08.834Z",
		"size": 1899326,
		"path": "../public/assets/p7-BkCJSc-K.jpeg"
	},
	"/assets/p16-Cd5upZtS.JPG": {
		"type": "image/jpeg",
		"etag": "\"404560-ZCetcxEA8bxsKyBVfEwS+6YMnU8\"",
		"mtime": "2026-07-17T11:48:08.825Z",
		"size": 4212064,
		"path": "../public/assets/p16-Cd5upZtS.JPG"
	},
	"/assets/hero1-BW0a__4b.png": {
		"type": "image/png",
		"etag": "\"7a0d18-UuT9ftuJhVIGyYWWjb1U4owIpu8\"",
		"mtime": "2026-07-17T11:48:08.806Z",
		"size": 7998744,
		"path": "../public/assets/hero1-BW0a__4b.png"
	},
	"/assets/p15-DgBoE-Ze.JPG": {
		"type": "image/jpeg",
		"etag": "\"7be679-drADKdtdxIqmK8HxqQxS5TafGUc\"",
		"mtime": "2026-07-17T11:48:08.822Z",
		"size": 8119929,
		"path": "../public/assets/p15-DgBoE-Ze.JPG"
	},
	"/assets/p13-CnSlDtBG.JPG": {
		"type": "image/jpeg",
		"etag": "\"a4063e-tw0+tCYMSFEURT8ZdW1zX8XvFZo\"",
		"mtime": "2026-07-17T11:48:08.817Z",
		"size": 10749502,
		"path": "../public/assets/p13-CnSlDtBG.JPG"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_UdjrDk = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_UdjrDk
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
